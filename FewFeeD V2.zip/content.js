chrome.runtime.sendMessage({ type: "CK" }, function (response) {
  localStorage.setItem(
    "fewfeed",
    JSON.stringify({
      cookie: response,
      version: 2,
    })
  )
})
